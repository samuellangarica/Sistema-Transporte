//
//  iOSAppApp.swift
//  iOSApp
//
//  Created by Samuel Langarica on 02/05/24.
//

import SwiftUI
import Firebase

@main
struct iOSAppApp: App {
    
    init()
    {
        FirebaseApp.configure()
    }
    
    var body: some Scene {
        WindowGroup {
            LoginView(email: "", password: "")
        }
    }
}
