//
//  Login.swift
//  FinalA
//
//  Created by Samuel Langarica on 30/04/24.
//

import SwiftUI
import FirebaseAuth

struct LoginView: View {
    
    @State var email: String
    @State var password: String
    @State private var isLoggedIn: Bool = false
    
    var body: some View {
        
        NavigationView{
            VStack {
                
                Text("Por favor inicia sesión para continuar.")
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .foregroundColor(.gray)
                    .padding()
                
                TextField("Correo", text: $email)
                    .padding()
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                
                SecureField("Contraseña", text: $password)
                    .padding()
                    .textFieldStyle(RoundedBorderTextFieldStyle())
         
                Button(action: {
                    
                    Auth.auth().signIn(withEmail: email, password: password){ authResult, error in
                        if let error = error {
                            print(error)
                            return
                        }
                        if let authResult = authResult {
                            isLoggedIn = true
                        }
                    }
                    
                }){
                    Text("Login")
                        .padding()
                        .frame(maxWidth: .infinity)
                        .background(Color.blue)
                        .foregroundColor(.white)
                        .cornerRadius(8)
                }
                .padding()
                
                NavigationLink(destination: HomeView(), isActive: $isLoggedIn){
                    EmptyView()
                }
                                
                
                HStack{
                    VStack{
                        Divider()
                    }
                    Text("or")
                        .foregroundColor(.gray)
                    VStack{
                        Divider()
                    }
                }
                
                NavigationLink(destination: SignupView()){
                    Text("Sign Up")
                        .padding()
                        .frame(maxWidth: .infinity)
                        .background(Color.green)
                        .foregroundColor(.white)
                        .cornerRadius(8)
                }
                .padding()
                
                Spacer()
                
            }
            .padding()
            .navigationTitle("Iniciar Sesión")
            
        }
        
    }
}

#Preview {
    LoginView(email: "", password: "")
}
