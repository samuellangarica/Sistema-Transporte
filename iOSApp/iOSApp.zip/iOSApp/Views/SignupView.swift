//
//  SignupView.swift
//  iOSApp
//
//  Created by Samuel Langarica on 02/05/24.
//

import SwiftUI
import FirebaseAuth
import FirebaseDatabase
import Firebase

struct SignupView: View {
    @State private var email = ""
    @State private var username = ""
    @State private var password = ""
    @State private var confirmPassword = ""

    var body: some View {
        VStack {
            Text("Sign Up")
                .font(.title)
                .padding()
            
            VStack(spacing: 20) {
                TextField("Correo", text: $email)
                    .padding()
                    .background(Color(UIColor.systemGray6))
                    .cornerRadius(10)
                
                TextField("Usuario", text: $username)
                    .padding()
                    .background(Color(UIColor.systemGray6))
                    .cornerRadius(10)
                
                SecureField("Contraseña", text: $password)
                    .padding()
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                
                SecureField("Confirmar contraseña", text: $confirmPassword)
                    .padding()
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                
                Button(action: signUp) {
                    Text("Sign Up")
                        .foregroundColor(.white)
                        .padding()
                        .frame(maxWidth: .infinity)
                        .background(Color.blue)
                        .cornerRadius(10)
                }
            }
            .padding()
            .textFieldStyle(RoundedBorderTextFieldStyle())
        }
        .padding()
    }

    
    func signUp() {
        if password == confirmPassword {
            Auth.auth().createUser(withEmail: email, password: password) { authResult, error in
                if let error = error {
                    // errorMessage = error.localizedDescription
                } else if let authResult = authResult {
                    // User successfully created, authResult contains information about the user
                    let newUser = [
                        "email": email,
                        "username": username
                    ]
                    let usersRef = Database.database().reference().child("users") // Assuming "users" is the parent node
                    usersRef.child(authResult.user.uid).setValue(newUser) { error, _ in
                        if let error = error {
                            // errorMessage = error.localizedDescription
                        } else {
                            // User details successfully inserted into the database
                            // You can navigate to the next screen or perform any other actions here
                        }
                    }
                }
            }
        } else {
            // errorMessage = "Passwords do not match"
        }
    }

}

struct SignUpView_Previews: PreviewProvider {
    static var previews: some View {
        SignupView()
    }
}
