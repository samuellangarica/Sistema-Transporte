import SwiftUI
import FirebaseAuth
import FirebaseDatabase

struct ProfileView: View {
    
    @State private var email: String = "Unknown"
    @State private var username: String = "Unknown"
    @State private var apellido: String = "Unknown"
    @State private var carrera: String = "Unknown"
    @State private var semestre: String = "Unknown"
    
    var rootRef: DatabaseReference = DatabaseReference()
    
    // Handling save confirmation alert
    @State private var showingConfirmationAlert = false
    
    // Handling sign out confirmation alert
    @State private var showingSignOutAlert = false
    
    // Environment variable to dismiss the current view
    @Environment(\.presentationMode) var presentationMode
    
    var body: some View {
        VStack {
            Text("Edita los detalles de tu cuenta")
            TextField("Email", text: $email)
                .textFieldStyle(RoundedBorderTextFieldStyle())
                .padding()
            
            TextField("Username", text: $username)
                .textFieldStyle(RoundedBorderTextFieldStyle())
                .padding()
            
            TextField("Apellido", text: $apellido)
                .textFieldStyle(RoundedBorderTextFieldStyle())
                .padding()
            
            TextField("Carrera", text: $carrera)
                .textFieldStyle(RoundedBorderTextFieldStyle())
                .padding()
            
            TextField("Semestre", text: $semestre)
                .textFieldStyle(RoundedBorderTextFieldStyle())
                .padding()
            
            Button(action: {
                let userID = Auth.auth().currentUser?.uid ?? "Unknown User"
                rootRef.child("users").child(userID).setValue(
                    [
                        "username": username,
                        "email": email,
                        "apellido": apellido,
                        "carrera": carrera,
                        "semestre": semestre
                    ]
                )
                showingConfirmationAlert = true
                // Dismiss current view
                presentationMode.wrappedValue.dismiss()
            }) {
                Image(systemName: "square.and.arrow.down")
                Text("Save Changes")
            }
            
            // Sign out button
            Spacer()
            Button(action: {
                signOut()
            }) {
                HStack {
                    Image(systemName: "arrowshape.turn.up.left.fill")
                    Text("Sign Out")
                }
            }
            .alert(isPresented: $showingSignOutAlert) {
                Alert(
                    title: Text("Signed Out"),
                    message: Text("You have been signed out successfully."),
                    dismissButton: .default(Text("OK")) {
                        // Navigate to login view or root view after sign out
                        presentationMode.wrappedValue.dismiss()
                    }
                )
            }
        }
        .padding()
        
        .alert(isPresented: $showingConfirmationAlert) {
            Alert(title: Text("Changes Saved"), message: Text("Your changes have been saved successfully."), dismissButton: .default(Text("OK")))
        }
        
        HStack { // Bottom bar
            Spacer()
            NavigationLink(destination: HomeView()) {
                Image(systemName: "ticket.fill")
                    .resizable()
                    .frame(width: 50, height: 50)
                    .foregroundColor(.green)
            }
            .padding()
            
            Spacer()
            
            NavigationLink(destination: ProfileView(rootRef: rootRef)) {
                Image(systemName: "person.circle.fill")
                    .resizable()
                    .frame(width: 50, height: 50)
                    .foregroundColor(.green)
            }
            .padding()
            
            Spacer()
        }
        .background(Color.primary)
        
        .onAppear {
            fetchUserData()
        }
    }
    
    private func fetchUserData() {
        let userID = Auth.auth().currentUser?.uid
        rootRef.child("users").child(userID!).observeSingleEvent(of: .value, with: { snapshot in
            if let value = snapshot.value as? [String: Any] {
                email = value["email"] as? String ?? ""
                username = value["username"] as? String ?? ""
                apellido = value["apellido"] as? String ?? ""
                carrera = value["carrera"] as? String ?? ""
                semestre = value["semestre"] as? String ?? ""
            }
        }) { error in
            print(error.localizedDescription)
        }
    }
    
    func signOut() {
        let firebaseAuth = Auth.auth()
        do{
            try firebaseAuth.signOut()
        } catch let signOutError as NSError {
            print("Error signing out: %@", signOutError)
        }
    }
}

#Preview {
    ProfileView()
}
